:man_page: mongoc_stream_tls_t

mongoc_stream_tls_t
===================

Synopsis
--------

.. code-block:: c

  typedef struct _mongoc_stream_tls_t mongoc_stream_tls_t

``mongoc_stream_tls_t`` is a :symbol:`mongoc_stream_t` subclass for working with OpenSSL TLS streams.

.. only:: html

  Functions
  ---------

  .. toctree::
    :titlesonly:
    :maxdepth: 1

