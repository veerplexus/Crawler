:man_page: bson_cross_platform_notes

Cross Platform Notes
====================

.. toctree::
  :titlesonly:

  endianness
  threading
